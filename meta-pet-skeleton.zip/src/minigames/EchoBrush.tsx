import React, { useRef } from 'react';

/**
 * EchoBrush mini‑game stub. Clicking on the canvas paints random
 * coloured squares. In the future this component will become a more
 * elaborate ritual or rhythm game that rewards the pet with mood
 * boosts and trait adjustments.
 */
const EchoBrush: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const handleClick = () => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = `hsl(${Math.random() * 360}, 60%, 60%)`;
    ctx.fillRect(
      Math.random() * (ctx.canvas.width - 20),
      Math.random() * (ctx.canvas.height - 20),
      20,
      20,
    );
  };

  return (
    <div className="space-y-2">
      <canvas
        ref={canvasRef}
        width={200}
        height={200}
        className="border border-gray-600"
        onClick={handleClick}
      />
      <p className="text-xs text-gray-400">Tap the canvas to draw.</p>
    </div>
  );
};

export default EchoBrush;