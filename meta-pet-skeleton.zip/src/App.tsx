import React from 'react';
import HUD from './ui/HUD';

/**
 * Root component. Renders the HUD and can be extended with additional
 * screens such as the Vimana map or mini‑games.
 */
const App: React.FC = () => {
  return (
    <div className="flex items-center justify-center h-screen w-screen bg-gray-900 text-white">
      <HUD />
    </div>
  );
};

export default App;