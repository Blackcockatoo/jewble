import { SaveFile } from '../store';

/**
 * Computes a simple hash from the save file. This is a placeholder
 * implementation of a watermark mechanism that will later be
 * replaced by a SHA3 or other cryptographic hash. The result is
 * appended to the export to discourage tampering.
 */
export function makeWatermark(save: SaveFile): string {
  const json = JSON.stringify(save);
  let hash = 0;
  for (let i = 0; i < json.length; i++) {
    const chr = json.charCodeAt(i);
    hash = (hash << 5) - hash + chr;
    hash |= 0; // Convert to 32bit integer
  }
  return Math.abs(hash).toString(16);
}