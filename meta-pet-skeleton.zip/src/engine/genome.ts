import { rngFor } from './rng';

/**
 * Represents a scaffolded genome. Each array holds 60 values in the
 * range [0,1), corresponding to the Red60, Blue60 and Black60
 * dimensions. Future iterations will attach richer semantics
 * (traits, cosmetic mappings, etc.).
 */
export interface Genome {
  red: number[];
  blue: number[];
  black: number[];
}

/**
 * Initialises a new genome based on the provided seed. This uses the
 * RNG defined in rng.ts to create stable sequences. As the project
 * evolves, this function will incorporate number‑theory based
 * sequencing and trait assignments.
 */
export function initGenome(seed: string): Genome {
  const rng = rngFor(seed);
  const build = () => Array.from({ length: 60 }, () => rng.next());
  return {
    red: build(),
    blue: build(),
    black: build(),
  };
}

/**
 * Applies drift/mutation to a genome over time. The context object
 * provides inputs that influence evolution, such as how well the
 * player has cared for the pet (careScore) and how much
 * exploration has occurred (explorationXP). For the MVP this
 * function simply returns the genome unchanged.
 */
export function driftGenome(
  genome: Genome,
  _deltaMs: number,
  _context: { careScore: number; explorationXP: number },
): Genome {
  // No drift applied in MVP.
  return genome;
}