/**
 * Enumerates the discrete evolutionary states of the Meta‑Pet. Pets
 * transition between these states based on conditions defined in
 * canEvolve. This type is kept as a union to aid type safety.
 */
export type PetState = 'genetics' | 'neurogenetics' | 'quantum' | 'speciation';

/**
 * Determines whether a pet meets the criteria to evolve into the
 * target state. The current MVP stub simply allows all transitions
 * but future implementations should consult the pet's vitals,
 * curiosity, exploration XP and other metrics.
 */
export function canEvolve(pet: any, target: PetState): boolean {
  // TODO: implement real gating logic.
  return true;
}

/**
 * Performs the evolution, producing a new pet object with the updated
 * state. Additional changes such as colour palettes or unlocked
 * capabilities should be handled here or in onEnterState.
 */
export function evolve(pet: any, target: PetState): any {
  return {
    ...pet,
    state: target,
  };
}

/**
 * Hook called when entering a new state. Use this to apply
 * side‑effects such as unlocking new care verbs, adjusting
 * cosmetics or journal logging. The MVP stub performs no changes.
 */
export function onEnterState(pet: any, state: PetState): any {
  // Placeholder for colourway and verb unlocking logic.
  return pet;
}