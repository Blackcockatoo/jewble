/**
 * A simple deterministic random number generator based on a linear
 * congruential generator. This implementation is intentionally
 * simplistic and will be replaced with the Red60/Blue60/Black60 RNG
 * specified in the Meta‑Pet design. It provides a stable sequence
 * of numbers for a given seed.
 */
export interface RNG {
  /**
   * Returns the next value in the pseudo‑random sequence in the range
   * [0,1). Each call mutates the internal state.
   */
  next(): number;
}

/**
 * Creates an RNG for the provided string seed. The seed is reduced
 * to a numeric value by summing char codes, then used to initialise
 * the LCG state. Note that this is a placeholder; future versions
 * should derive seeds from the B$S number‑theory scaffolds.
 */
export function rngFor(seed: string): RNG {
  let state = 0;
  for (let i = 0; i < seed.length; i++) {
    state += seed.charCodeAt(i);
  }
  return {
    next() {
      // LCG constants: see Numerical Recipes or similar texts.
      state = (state * 48271) % 0x7fffffff;
      return state / 0x7fffffff;
    },
  };
}