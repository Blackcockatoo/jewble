import { useGameStore } from '../store';

// Rates at which each vital decays per millisecond. These values are
// intentionally small so that changes occur over the course of
// several minutes. Tune these constants to adjust the pace of the
// game. A value of 0.0001 reduces a bar from full to empty in
// roughly 10,000ms / 0.0001 = 100,000ms (~1.6min).
const DECAY_RATES = {
  hunger: 0.0001,
  hygiene: 0.00005,
  mood: 0.00002,
  energy: 0.00003,
};

/**
 * Advances the simulation by the provided delta in milliseconds. This
 * function reads the current pet from the store and updates its
 * vitals based on the configured decay rates. Vitals are clamped
 * between 0 and 1.
 */
export function tick(deltaMs: number): void {
  const store = useGameStore.getState();
  store.setPet((pet) => {
    const { hunger, hygiene, mood, energy } = pet.vitals;
    const newVitals = {
      hunger: Math.max(0, hunger - DECAY_RATES.hunger * deltaMs),
      hygiene: Math.max(0, hygiene - DECAY_RATES.hygiene * deltaMs),
      mood: Math.max(0, mood - DECAY_RATES.mood * deltaMs),
      energy: Math.max(0, energy - DECAY_RATES.energy * deltaMs),
    };
    return {
      ...pet,
      vitals: newVitals,
    };
  });
}