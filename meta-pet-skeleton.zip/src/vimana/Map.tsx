import React from 'react';
import { useGameStore } from '../store';

/**
 * Simple Vimana map stub. Renders a grid of cells that can be clicked
 * to move the pet. Each cell is assigned a field type in a
 * repeating pattern. Real implementation would load this data from
 * the store or procedurally generate it.
 */
const GRID_SIZE = 8;
const fields = ['calm', 'neuro', 'quantum', 'earth'] as const;

const VimanaMap: React.FC = () => {
  const map = useGameStore((state) => state.vimanaMap);
  const moveToCell = useGameStore((state) => state.moveToCell);

  return (
    <div className="grid grid-cols-8 gap-1">
      {Array.from({ length: GRID_SIZE * GRID_SIZE }, (_, idx) => {
        const cell = map[idx] ?? {
          id: String(idx),
          field: fields[idx % fields.length],
        };
        const label = cell.field[0].toUpperCase();
        return (
          <div
            key={cell.id}
            className="w-8 h-8 border border-gray-600 flex items-center justify-center cursor-pointer text-xs select-none"
            onClick={() => moveToCell(cell.id)}
          >
            {label}
          </div>
        );
      })}
    </div>
  );
};

export default VimanaMap;