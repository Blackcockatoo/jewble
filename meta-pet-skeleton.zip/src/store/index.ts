import { create } from 'zustand';
import { initGenome, Genome } from '../engine/genome';
import { PetState } from '../engine/state';

// Define core data models used across the application.
export interface PetVitals {
  hunger: number;
  hygiene: number;
  mood: number;
  energy: number;
}

export interface Pet {
  name: string;
  state: PetState;
  vitals: PetVitals;
  genome: Genome;
  curiosity: number;
  explorationXP: number;
}

export interface VimanaCell {
  id: string;
  field: 'calm' | 'neuro' | 'quantum' | 'earth';
  anomaly?: boolean;
}

export interface SaveFile {
  version: string;
  pet: Pet;
  map: VimanaCell[];
}

export interface GameStore {
  pet: Pet;
  vimanaMap: VimanaCell[];
  /** Updates the pet by applying the provided transform function. */
  setPet: (update: (pet: Pet) => Pet) => void;
  /** Moves the pet to a new cell on the Vimana map. */
  moveToCell: (cellId: string) => void;
}

/**
 * Creates the Zustand store. Initial state uses a deterministic genome
 * derived from the pet name. The map is left empty and will be
 * initialised by the Vimana components.
 */
export const useGameStore = create<GameStore>((set, get) => ({
  pet: {
    name: 'Meta',
    state: 'genetics',
    vitals: {
      hunger: 1,
      hygiene: 1,
      mood: 1,
      energy: 1,
    },
    genome: initGenome('Meta'),
    curiosity: 0,
    explorationXP: 0,
  },
  vimanaMap: [],
  setPet: (update) =>
    set((state) => ({
      pet: update(state.pet),
    })),
  moveToCell: (cellId) => {
    // placeholder: this would update curiosity and explorationXP
    const map = get().vimanaMap;
    const cell = map.find((c) => c.id === cellId);
    if (cell) {
      set((state) => ({
        pet: {
          ...state.pet,
          curiosity: state.pet.curiosity + 1,
          explorationXP: state.pet.explorationXP + 1,
        },
      }));
    }
  },
}));