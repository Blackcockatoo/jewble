import React from 'react';

interface VitalsProps {
  vitals: {
    hunger: number;
    hygiene: number;
    mood: number;
    energy: number;
  };
}

interface BarProps {
  label: string;
  value: number;
  color: string;
}

// Renders a single horizontal bar representing a vital. The bar
// length reflects the value and is clamped between 0 and 1.
const Bar: React.FC<BarProps> = ({ label, value, color }) => {
  return (
    <div className="w-full">
      <div className="text-xs text-gray-300">{label}</div>
      <div className="bg-gray-700 h-2 rounded">
        <div
          className={`${color} h-2 rounded transition-all`}
          style={{ width: `${Math.max(0, Math.min(1, value)) * 100}%` }}
        />
      </div>
    </div>
  );
};

/**
 * Displays all vitals for a pet. Each bar uses a colour tied to
 * the meaning of the vital.
 */
const Vitals: React.FC<VitalsProps> = ({ vitals }) => {
  return (
    <div className="space-y-2">
      <Bar label="Hunger" value={vitals.hunger} color="bg-red-500" />
      <Bar label="Hygiene" value={vitals.hygiene} color="bg-blue-500" />
      <Bar label="Mood" value={vitals.mood} color="bg-green-500" />
      <Bar label="Energy" value={vitals.energy} color="bg-yellow-500" />
    </div>
  );
};

export default Vitals;