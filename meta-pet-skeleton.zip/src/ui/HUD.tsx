import React from 'react';
import { useGameStore } from '../store';
import Vitals from './Vitals';

/**
 * Heads‑up display showing the pet's name, current state and vitals.
 * Also renders action buttons that allow the user to care for their
 * pet. The actual verb implementations are stubs in the MVP.
 */
const HUD: React.FC = () => {
  const pet = useGameStore((state) => state.pet);

  const feed = () => {
    useGameStore.getState().setPet((current) => ({
      ...current,
      vitals: { ...current.vitals, hunger: 1 },
    }));
  };
  const clean = () => {
    useGameStore.getState().setPet((current) => ({
      ...current,
      vitals: { ...current.vitals, hygiene: 1 },
    }));
  };
  const play = () => {
    useGameStore.getState().setPet((current) => ({
      ...current,
      vitals: { ...current.vitals, mood: 1 },
    }));
  };
  const rest = () => {
    useGameStore.getState().setPet((current) => ({
      ...current,
      vitals: { ...current.vitals, energy: 1 },
    }));
  };

  return (
    <div className="p-4 bg-gray-800 rounded-lg shadow-lg space-y-4 w-64">
      <div>
        <div className="text-2xl font-bold">{pet.name}</div>
        <div className="text-sm text-gray-400">State: {pet.state}</div>
      </div>
      <Vitals vitals={pet.vitals} />
      <div className="flex flex-wrap gap-2">
        <button
          className="px-2 py-1 rounded bg-red-600 hover:bg-red-700 text-white text-xs"
          onClick={feed}
        >
          Feed
        </button>
        <button
          className="px-2 py-1 rounded bg-blue-600 hover:bg-blue-700 text-white text-xs"
          onClick={clean}
        >
          Clean
        </button>
        <button
          className="px-2 py-1 rounded bg-green-600 hover:bg-green-700 text-white text-xs"
          onClick={play}
        >
          Play
        </button>
        <button
          className="px-2 py-1 rounded bg-yellow-600 hover:bg-yellow-700 text-white text-xs"
          onClick={rest}
        >
          Rest
        </button>
      </div>
    </div>
  );
};

export default HUD;