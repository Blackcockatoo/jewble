import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Vite configuration for Meta‑Pet.
// Provides React support and leaves room for further customization.
export default defineConfig({
  plugins: [react()],
});