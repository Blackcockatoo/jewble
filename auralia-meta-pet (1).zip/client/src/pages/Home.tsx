import AuraliaMetaPet from "@/components/AuraliaMetaPet";

export default function Home() {
  return <AuraliaMetaPet />;
}
