import React from "react";
import { View, Text } from "react-native";

export default function Index() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Meta-Pet Mobile</Text>
      <Text>Dashboard/HUD</Text>
    </View>
  );
}
