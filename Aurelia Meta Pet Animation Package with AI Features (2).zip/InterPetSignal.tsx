import React, { useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withRepeat,
  interpolate,
  Extrapolate,
} from 'react-native-reanimated';

interface InterPetSignalProps {
  size?: number;
  primaryColor?: string;
}

/**
 * UPGRADE 11: Inter-Pet Communication Signal (Placeholder)
 * Simulates a subtle, high-frequency pulse emitted by the pet.
 * NOTE: Actual BLE/Wi-Fi Direct detection requires native code setup and permissions.
 * This component simulates the visual effect of the signal.
 */
export function InterPetSignal({
  size = 200,
  primaryColor = '#00D9A5',
}: InterPetSignalProps) {
  // Shared value to simulate the signal strength (0 to 1)
  const signalStrength = useSharedValue(0);

  useEffect(() => {
    // Simulate a periodic signal burst (e.g., every 5 seconds)
    signalStrength.value = withRepeat(
      withTiming(1, { duration: 500 }), // Quick burst
      -1,
      false // Do not reverse, just reset
    );
  }, []);

  // Number of signal rings
  const NUM_RINGS = 3;
  const ringElements = Array.from({ length: NUM_RINGS }, (_, i) => {
    const animatedStyle = useAnimatedStyle(() => {
      // Each ring expands from the center
      const delay = i * 200; // Stagger the rings
      const progress = interpolate(
        signalStrength.value,
        [0, 1],
        [0, 1],
        Extrapolate.CLAMP
      );

      // Scale the ring from 0 to 1.5
      const scale = progress * 1.5;
      // Opacity fades out as it expands
      const opacity = 1 - progress;

      return {
        transform: [{ scale: scale }],
        opacity: opacity,
      };
    });

    return (
      <Animated.View
        key={i}
        style={[
          styles.ring,
          {
            borderColor: primaryColor,
            width: size,
            height: size,
            borderRadius: size / 2,
          },
          animatedStyle,
        ]}
      />
    );
  });

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      {ringElements}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 0, // Behind the pet
  },
  ring: {
    position: 'absolute',
    borderWidth: 2,
  },
});
