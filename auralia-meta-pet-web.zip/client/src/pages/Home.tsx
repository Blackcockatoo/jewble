/**
 * Home Page - Auralia Meta Pet Web Edition
 * Main interactive pet display with all 13 upgrades
 */

import React, { useState } from 'react';
import { PetMorph } from '@/components/PetMorph';
import { GeometricBackground } from '@/components/GeometricBackground';
import { VaultExplanationModal } from '@/components/VaultExplanationModal';
import { HeptaTag } from '@/components/HeptaTag';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';

type VaultType = 'red' | 'blue' | 'black' | 'hepta' | null;

interface Vitals {
  energy: number;
  curiosity: number;
  bond: number;
  mood: number;
  hunger: number;
  hygiene: number;
}

export default function Home() {
  const [petPosition, setPetPosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [selectedVault, setSelectedVault] = useState<VaultType>(null);
  const [vitals, setVitals] = useState<Vitals>({
    energy: 75,
    curiosity: 60,
    bond: 80,
    mood: 70,
    hunger: 40,
    hygiene: 85,
  });

  const updateVital = (key: keyof Vitals, value: number) => {
    setVitals((prev) => ({ ...prev, [key]: value }));
  };

  // Generate sample hepta codes
  const generateHeptaCode = () => {
    return Array.from({ length: 12 }, () => Math.floor(Math.random() * 7)).join('');
  };

  const redVaultCode = generateHeptaCode();
  const blueVaultCode = generateHeptaCode();
  const blackVaultCode = generateHeptaCode();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
            Auralia Meta Pet
          </h1>
          <p className="text-slate-400 mt-2">Interactive Sacred Geometry Guardian with 13 Advanced Upgrades</p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Main Pet Display */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Pet Visualization */}
          <div className="lg:col-span-2">
            <Card className="bg-slate-800/50 border-slate-700 p-8 relative overflow-hidden">
              <div className="absolute inset-0">
                <GeometricBackground size={500} petPosition={petPosition} />
              </div>
              <div className="relative z-10 flex justify-center items-center" style={{ height: 500 }}>
                <PetMorph vitals={vitals} size={300} onPositionChange={setPetPosition} />
              </div>
            </Card>
          </div>

          {/* Vitals Panel */}
          <div className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700 p-6">
              <h2 className="text-xl font-bold text-white mb-4">Pet Vitals</h2>
              <div className="space-y-4">
                {Object.entries(vitals).map(([key, value]) => (
                  <div key={key}>
                    <div className="flex justify-between mb-2">
                      <label className="text-sm font-medium text-slate-300 capitalize">{key}</label>
                      <span className="text-sm font-bold text-purple-400">{value.toFixed(0)}</span>
                    </div>
                    <Slider
                      value={[value]}
                      onValueChange={(val) => updateVital(key as keyof Vitals, val[0])}
                      min={0}
                      max={100}
                      step={1}
                      className="w-full"
                    />
                  </div>
                ))}
              </div>
            </Card>

            {/* Info Button */}
            <Button
              onClick={() => setSelectedVault('hepta')}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
            >
              Learn About Hepta System
            </Button>
          </div>
        </div>

        {/* Hepta Vaults Section */}
        <Card className="bg-slate-800/50 border-slate-700 p-8">
          <h2 className="text-2xl font-bold text-white mb-6">Genome Vaults</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Red Vault */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-red-400">Red Vault</h3>
              <p className="text-sm text-slate-400">Physical form and base stats</p>
              <HeptaTag
                heptaCode={redVaultCode}
                onPress={() => console.log('Play Red Vault audio')}
                onInfoPress={() => setSelectedVault('red')}
              />
            </div>

            {/* Blue Vault */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-blue-400">Blue Vault</h3>
              <p className="text-sm text-slate-400">Personality and temperament</p>
              <HeptaTag
                heptaCode={blueVaultCode}
                onPress={() => console.log('Play Blue Vault audio')}
                onInfoPress={() => setSelectedVault('blue')}
              />
            </div>

            {/* Black Vault */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-slate-300">Black Vault</h3>
              <p className="text-sm text-slate-400">Evolution and latent abilities</p>
              <HeptaTag
                heptaCode={blackVaultCode}
                onPress={() => console.log('Play Black Vault audio')}
                onInfoPress={() => setSelectedVault('black')}
              />
            </div>
          </div>
        </Card>

        {/* Features Overview */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { title: 'Hepta-Chromatic Aura', desc: 'Dynamic color based on vitals' },
            { title: 'Fractalized Shell', desc: 'Geometry-driven appearance' },
            { title: 'Temporal Echo Trail', desc: 'Movement memory effect' },
            { title: 'Particle Field', desc: 'Energy visualization' },
            { title: 'Proximity Warp', desc: 'Space-bending background' },
            { title: 'Shadow Projection', desc: 'Dynamic shadow effects' },
            { title: 'Behavior Engine', desc: 'AI-driven animations' },
            { title: 'Memory Corruption', desc: 'Hygiene-based glitches' },
          ].map((feature, idx) => (
            <Card key={idx} className="bg-slate-800/50 border-slate-700 p-4">
              <h3 className="font-semibold text-sm text-purple-400">{feature.title}</h3>
              <p className="text-xs text-slate-400 mt-1">{feature.desc}</p>
            </Card>
          ))}
        </div>
      </main>

      {/* Vault Explanation Modal */}
      <VaultExplanationModal
        visible={selectedVault !== null}
        vault={selectedVault}
        onClose={() => setSelectedVault(null)}
      />
    </div>
  );
}
