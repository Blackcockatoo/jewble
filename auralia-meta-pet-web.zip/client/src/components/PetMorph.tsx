/**
 * PetMorph Component - Web Edition
 * Displays the Auralia meta-pet with advanced animations and visual effects
 * Includes all 13 upgrades adapted for web (SVG + CSS animations)
 */

import React, { useEffect, useRef, useState } from 'react';
import { getHeptaChromaticColor, getFractalizedPath, getMemoryCorruptionOffset, getDynamicShadowPath } from '@/lib/petUpgrades';

interface Vitals {
  energy: number;
  curiosity: number;
  bond: number;
  mood: number;
  hunger: number;
  hygiene: number;
}

interface PetMorphProps {
  vitals: Vitals;
  size?: number;
  onPositionChange?: (position: { x: number; y: number }) => void;
}

export const PetMorph: React.FC<PetMorphProps> = ({
  vitals,
  size = 400,
  onPositionChange,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [animationTime, setAnimationTime] = useState(0);

  // Track pet position for proximity-based warp
  useEffect(() => {
    if (!containerRef.current || !onPositionChange) return;

    const rect = containerRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    onPositionChange({ x: centerX, y: centerY });
  }, [onPositionChange]);

  // Animation loop for time-based effects
  useEffect(() => {
    let animationId: number;
    let lastTime = Date.now();

    const animate = () => {
      const now = Date.now();
      const deltaTime = (now - lastTime) / 1000;
      lastTime = now;

      setAnimationTime((prev) => prev + deltaTime);
      animationId = requestAnimationFrame(animate);
    };

    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, []);

  // Get colors and paths based on vitals
  const primaryColor = getHeptaChromaticColor(vitals);
  const fractalPath = getFractalizedPath(vitals.hygiene, size);
  const { x: corruptionX, y: corruptionY } = getMemoryCorruptionOffset(vitals.hygiene);
  const shadowPath = getDynamicShadowPath(vitals.hunger, size);

  // Calculate animation parameters
  const glowIntensity = (vitals.energy / 100) * 0.8;
  const flickerOpacity = 0.3 + Math.sin(animationTime * vitals.mood * Math.PI) * 0.2;
  const scaleAmount = 1 + Math.sin(animationTime * 2) * 0.05;

  return (
    <div
      ref={containerRef}
      className="relative flex items-center justify-center"
      style={{
        width: size,
        height: size,
        perspective: '1000px',
      }}
    >
      {/* Glow effect */}
      <div
        className="absolute inset-0 rounded-full blur-3xl opacity-50 transition-all duration-300"
        style={{
          backgroundColor: primaryColor,
          opacity: glowIntensity,
          transform: `scale(${scaleAmount})`,
        }}
      />

      {/* Main pet SVG */}
      <svg
        viewBox={`0 0 ${size} ${size}`}
        width={size}
        height={size}
        className="relative z-10"
        style={{
          filter: `drop-shadow(0 0 ${20 * glowIntensity}px ${primaryColor})`,
        }}
      >
        <defs>
          {/* Radial gradient for pet body */}
          <radialGradient id="petGradient" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={primaryColor} stopOpacity="0.8" />
            <stop offset="100%" stopColor={primaryColor} stopOpacity="0.3" />
          </radialGradient>

          {/* Shadow filter */}
          <filter id="shadow">
            <feDropShadow dx="0" dy="4" stdDeviation="3" floodOpacity="0.3" />
          </filter>
        </defs>

        {/* Dynamic shadow (Upgrade 12) */}
        <path
          d={shadowPath}
          fill={primaryColor}
          opacity="0.15"
          transform={`translate(${corruptionX * 0.5}, ${corruptionY * 0.5})`}
        />

        {/* Fractalized shell (Upgrade 2) */}
        <path
          d={fractalPath}
          fill="url(#petGradient)"
          stroke={primaryColor}
          strokeWidth="1"
          transform={`translate(${corruptionX}, ${corruptionY})`}
          filter="url(#shadow)"
        />

        {/* Energy rings */}
        {[0, 1, 2].map((i) => (
          <circle
            key={`ring-${i}`}
            cx={size / 2 + corruptionX * 0.5}
            cy={size / 2 + corruptionY * 0.5}
            r={45 + i * 5}
            fill="none"
            stroke={primaryColor}
            strokeWidth="1"
            opacity={0.2 * (vitals.energy / 100)}
            style={{
              animation: `rotate ${3 + i * 0.5}s linear infinite`,
            }}
          />
        ))}

        {/* Seed of Life pattern overlay with cognitive load flicker (Upgrade 0) */}
        <g
          opacity={flickerOpacity}
          style={{
            animation: `flicker ${0.1 + (100 - vitals.mood) / 1000}s infinite`,
          }}
        >
          <circle
            cx={size / 2}
            cy={size / 2}
            r="20"
            fill="none"
            stroke={primaryColor}
            strokeWidth="1.5"
          />
          {Array.from({ length: 6 }).map((_, i) => {
            const angle = (i / 6) * Math.PI * 2;
            const x = size / 2 + Math.cos(angle) * 20;
            const y = size / 2 + Math.sin(angle) * 20;
            return (
              <circle
                key={`petal-${i}`}
                cx={x}
                cy={y}
                r="20"
                fill="none"
                stroke={primaryColor}
                strokeWidth="1"
                opacity="0.6"
              />
            );
          })}
        </g>
      </svg>

      {/* CSS animations */}
      <style>{`
        @keyframes rotate {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }

        @keyframes flicker {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 0.8; }
        }

        @keyframes pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.05); }
        }
      `}</style>
    </div>
  );
};
