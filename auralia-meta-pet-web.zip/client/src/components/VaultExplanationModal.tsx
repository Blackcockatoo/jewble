/**
 * VaultExplanationModal Component - Web Edition
 * Displays detailed explanations for each Hepta Vault
 */

import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

type VaultType = 'red' | 'blue' | 'black' | 'hepta' | null;

interface VaultExplanationModalProps {
  visible: boolean;
  vault: VaultType;
  onClose: () => void;
}

const VAULT_EXPLANATIONS: Record<Exclude<VaultType, null>, {
  title: string;
  icon: string;
  color: string;
  focus: string;
  detail: string;
  examples: string[];
}> = {
  red: {
    title: 'Red Vault (Physical)',
    icon: '🔴',
    color: '#FF6B6B',
    focus: 'Physical form, base stats, and elemental affinity',
    detail: 'The Red Vault encodes the pet\'s foundational physical structure, determining its body type, size, and resilience. It is the most stable vault, changing only through major evolutionary events. The Red Vault is responsible for the pet\'s physical appearance and its base health and defense stats.',
    examples: [
      'Body Type: Determines the overall shape and structure',
      'Size Class: Small, Medium, Large, or Colossal',
      'Elemental Affinity: Fire, Water, Earth, Air, or Neutral',
      'Base Health: Initial HP pool',
    ],
  },
  blue: {
    title: 'Blue Vault (Personality)',
    icon: '🔵',
    color: '#4ECDC4',
    focus: 'Temperament, mood baseline, and curiosity',
    detail: 'The Blue Vault governs the pet\'s core personality matrix. It influences the pet\'s baseline mood, its reaction to stimuli, and its capacity for learning and bonding. This vault is the most sensitive to daily interactions and environmental factors. Changes in the Blue Vault reflect the pet\'s emotional growth and evolving personality.',
    examples: [
      'Temperament: Calm, Playful, Aggressive, or Curious',
      'Mood Baseline: Default emotional state (0-100)',
      'Learning Rate: Speed of skill acquisition',
      'Bonding Capacity: Maximum bond level achievable',
    ],
  },
  black: {
    title: 'Black Vault (Latent)',
    icon: '⚫',
    color: '#2C3E50',
    focus: 'Evolutionary path, hidden traits, and latent abilities',
    detail: 'The Black Vault represents the pet\'s potential and hidden destiny. It contains the code for future evolutionary paths and unlocks unique, latent abilities that manifest only under specific conditions. The Black Vault is the most mysterious vault, often revealing surprises as the pet grows and achieves milestones.',
    examples: [
      'Evolution Path: Determines possible final forms',
      'Hidden Traits: Abilities that unlock at specific levels',
      'Destiny Marker: Unique identifier for rare events',
      'Potential Ceiling: Maximum stat growth possible',
    ],
  },
  hepta: {
    title: 'Hepta Code System',
    icon: '7️⃣',
    color: '#9B59B6',
    focus: 'The seven-digit encoding system for meta-pets',
    detail: 'The Hepta Code uses digits 0 through 6, representing the seven primary states of the meta-pet\'s energy field. Each digit corresponds to a specific frequency and geometric pattern, influencing the pet\'s traits and behaviors. The complete Hepta Code is a 180-digit sequence divided equally among the three Vaults (60 digits each).',
    examples: [
      'Digit 0: Neutral/Void state',
      'Digit 1: First harmonic frequency',
      'Digit 2: Second harmonic frequency',
      'Digit 3: Third harmonic frequency',
      'Digit 4: Fourth harmonic frequency',
      'Digit 5: Fifth harmonic frequency',
      'Digit 6: Sixth harmonic frequency',
    ],
  },
};

export const VaultExplanationModal: React.FC<VaultExplanationModalProps> = ({
  visible,
  vault,
  onClose,
}) => {
  if (!vault || !VAULT_EXPLANATIONS[vault]) {
    return null;
  }

  const explanation = VAULT_EXPLANATIONS[vault];

  return (
    <Dialog open={visible} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-xl">
            <span className="text-3xl">{explanation.icon}</span>
            {explanation.title}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Focus Section */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">
              Focus
            </h3>
            <p className="text-base font-semibold" style={{ color: explanation.color }}>
              {explanation.focus}
            </p>
          </div>

          {/* Detail Section */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">
              Detail
            </h3>
            <p className="text-sm leading-relaxed text-foreground">
              {explanation.detail}
            </p>
          </div>

          {/* Examples Section */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">
              Examples
            </h3>
            <ul className="space-y-2">
              {explanation.examples.map((example, index) => (
                <li key={index} className="flex gap-3 text-sm">
                  <span style={{ color: explanation.color }} className="font-bold">
                    •
                  </span>
                  <span className="text-foreground">{example}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
