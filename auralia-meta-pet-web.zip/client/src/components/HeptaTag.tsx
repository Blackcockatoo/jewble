/**
 * HeptaTag Component - Web Edition
 * Displays a hepta code with interactive info button
 */

import React from 'react';
import { Button } from '@/components/ui/button';
import { Info } from 'lucide-react';

interface HeptaTagProps {
  heptaCode: string;
  onPress?: () => void;
  onInfoPress?: () => void;
  variant?: 'default' | 'compact' | 'large';
}

export const HeptaTag: React.FC<HeptaTagProps> = ({
  heptaCode,
  onPress,
  onInfoPress,
  variant = 'default',
}) => {
  // Format hepta code with dashes for readability
  const formatHepta = (code: string) => {
    if (code.length <= 8) return code;
    const chunks = code.match(/.{1,4}/g) || [];
    return chunks.join('-');
  };

  const formattedCode = formatHepta(heptaCode);

  const sizeClasses = {
    compact: 'text-xs px-2 py-1',
    default: 'text-sm px-4 py-2',
    large: 'text-base px-6 py-3',
  };

  return (
    <div className="flex items-center gap-2">
      <button
        onClick={onPress}
        className={`
          border-2 border-primary rounded-lg font-mono font-semibold tracking-wider
          bg-secondary hover:bg-secondary/80 transition-colors
          ${sizeClasses[variant]}
          ${onPress ? 'cursor-pointer' : 'cursor-default'}
          flex-1
        `}
      >
        {formattedCode}
      </button>
      {onInfoPress && (
        <Button
          variant="ghost"
          size="icon"
          onClick={onInfoPress}
          className="h-auto w-auto p-2"
          title="Learn more about this vault"
        >
          <Info className="w-4 h-4" />
        </Button>
      )}
    </div>
  );
};
