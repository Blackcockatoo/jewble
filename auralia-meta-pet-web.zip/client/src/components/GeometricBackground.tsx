/**
 * GeometricBackground Component - Web Edition
 * Implements the Oscillating Aperture Illusion with Proximity-Based Warp
 */

import React, { useEffect, useRef, useState } from 'react';

interface GeometricBackgroundProps {
  size?: number;
  petPosition?: { x: number; y: number };
}

export const GeometricBackground: React.FC<GeometricBackgroundProps> = ({
  size = 400,
  petPosition,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [animationTime, setAnimationTime] = useState(0);

  // Animation loop
  useEffect(() => {
    let animationId: number;
    let lastTime = Date.now();

    const animate = () => {
      const now = Date.now();
      const deltaTime = (now - lastTime) / 1000;
      lastTime = now;

      setAnimationTime((prev) => prev + deltaTime);
      animationId = requestAnimationFrame(animate);
    };

    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, []);

  // Draw the geometric background
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = size;
    canvas.height = size;

    // Clear canvas
    ctx.fillStyle = 'rgba(15, 15, 35, 1)';
    ctx.fillRect(0, 0, size, size);

    // Draw concentric circles with oscillating effect
    const centerX = size / 2;
    const centerY = size / 2;
    const maxRadius = size / 2;
    const circleCount = 15;
    const amplitude = 5;

    const t = animationTime;

    for (let n = 1; n < circleCount; n++) {
      // Base radius
      const baseR = (maxRadius / circleCount) * n;

      // Oscillation effect (expansion and contraction)
      const modulation = Math.sin(t * Math.PI * 2 - (n / circleCount) * Math.PI * 2) * amplitude;
      let r = baseR + modulation;

      // UPGRADE 5: Proximity-Based Warp
      let proximityWarp = 0;
      if (petPosition) {
        const petX = petPosition.x;
        const petY = petPosition.y;

        // Calculate distance from circle center to pet
        const dx = centerX - petX;
        const dy = centerY - petY;
        const distance = Math.sqrt(dx * dx + dy * dy);

        // Apply radial distortion effect
        const warpRadius = 100; // Radius of the warp effect
        const warpStrength = Math.max(0, 1 - distance / warpRadius);
        proximityWarp = warpStrength * 3 * Math.sin(t * Math.PI * 2);
      }

      r += proximityWarp;

      // Interpolate opacity for pulse effect
      const opacity = 0.3 + 0.3 * Math.sin(t * Math.PI * 2 - (n / circleCount) * Math.PI * 2);

      // Draw circle
      ctx.strokeStyle = `rgba(140, 158, 255, ${opacity})`;
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      ctx.arc(centerX, centerY, r, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Draw radial lines for additional geometric intensity
    const lineCount = 12;
    for (let i = 0; i < lineCount; i++) {
      const angle = (i / lineCount) * Math.PI * 2;
      const x1 = centerX + Math.cos(angle) * 20;
      const y1 = centerY + Math.sin(angle) * 20;
      const x2 = centerX + Math.cos(angle) * maxRadius;
      const y2 = centerY + Math.sin(angle) * maxRadius;

      // Pulsing opacity
      const opacity = 0.2 + 0.1 * Math.sin(t * Math.PI * 2 + angle);

      ctx.strokeStyle = `rgba(140, 158, 255, ${opacity})`;
      ctx.lineWidth = 0.3;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }
  }, [animationTime, size, petPosition]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 rounded-lg"
      style={{
        width: size,
        height: size,
        background: 'linear-gradient(135deg, #0f0f23 0%, #1a1a3a 100%)',
      }}
    />
  );
};
