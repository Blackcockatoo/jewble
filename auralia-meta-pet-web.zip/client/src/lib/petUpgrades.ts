/**
 * Pet Upgrades Utility Library - Web Edition
 * Contains logic for all 13 upgrades adapted for web
 */

interface Vitals {
  energy: number;
  curiosity: number;
  bond: number;
  mood: number;
  hunger: number;
  hygiene: number;
}

// ===== UPGRADE 1: Hepta-Chromatic Aura =====
/**
 * Maps two vitals (Energy and Hunger) to a 7-point color wheel
 */
export function getHeptaChromaticColor(vitals: Vitals): string {
  const colors = [
    '#FF6B6B', // Red (Low Energy, High Hunger)
    '#FFA500', // Orange
    '#FFD93D', // Yellow
    '#6BCB77', // Green (High Energy, Low Hunger)
    '#4D96FF', // Blue
    '#9B59B6', // Purple
    '#FF1493', // Magenta (Low Energy, Low Hunger)
  ];

  const energyWeight = 0.6;
  const hungerWeight = 0.4;
  const normalizedValue = vitals.energy * energyWeight + (100 - vitals.hunger) * hungerWeight;

  const colorIndex = Math.round((normalizedValue / 100) * (colors.length - 1));
  return colors[Math.max(0, Math.min(colorIndex, colors.length - 1))];
}

// ===== UPGRADE 2: Fractalized Shell =====
/**
 * Generates a fractal-like SVG path for the pet's main body
 * The fractal's complexity is driven by hygiene vital
 */
export function getFractalizedPath(hygiene: number, size: number): string {
  const centerX = size / 2;
  const centerY = size / 2;
  const baseRadius = 40;
  const iterations = Math.floor((hygiene / 100) * 3) + 1;

  let path = `M ${centerX} ${centerY - baseRadius}`;

  for (let i = 0; i < 360; i += 30) {
    const angle = (i * Math.PI) / 180;
    let radius = baseRadius;

    // Add fractal-like variation based on iterations
    for (let j = 0; j < iterations; j++) {
      const variation = Math.sin((angle * (j + 1)) / Math.PI) * 5;
      radius += variation;
    }

    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);

    if (i === 0) {
      path += `L ${x} ${y}`;
    } else {
      path += `L ${x} ${y}`;
    }
  }

  path += ' Z';
  return path;
}

// ===== UPGRADE 9: Memory Corruption Effect =====
/**
 * Returns random offsets for visual glitches when hygiene is low
 */
export function getMemoryCorruptionOffset(hygiene: number): { x: number; y: number } {
  if (hygiene > 50) return { x: 0, y: 0 };

  const corruptionIntensity = (50 - hygiene) / 50;
  const x = (Math.random() - 0.5) * 10 * corruptionIntensity;
  const y = (Math.random() - 0.5) * 10 * corruptionIntensity;

  return { x, y };
}

// ===== UPGRADE 12: Dynamic Shadow Projection =====
/**
 * Generates a shadow path that changes based on hunger vital
 */
export function getDynamicShadowPath(hunger: number, size: number): string {
  const centerX = size / 2;
  const centerY = size / 2;
  const baseRadius = 45;
  const shadowStretch = (hunger / 100) * 20;

  // Create an ellipse-like shadow that stretches based on hunger
  const radiusX = baseRadius + shadowStretch;
  const radiusY = baseRadius * 0.6;

  return `M ${centerX - radiusX} ${centerY}
          A ${radiusX} ${radiusY} 0 1 0 ${centerX + radiusX} ${centerY}
          A ${radiusX} ${radiusY} 0 1 0 ${centerX - radiusX} ${centerY}`;
}

// ===== UPGRADE 8: Predictive State Glitch =====
/**
 * Predicts the next vital state based on current vitals
 */
export function predictNextVitals(vitals: Vitals): Vitals {
  // Simple linear prediction: assume trends continue
  return {
    energy: Math.max(0, Math.min(100, vitals.energy - 0.5)), // Energy decreases over time
    curiosity: Math.max(0, Math.min(100, vitals.curiosity + 0.2)), // Curiosity increases
    bond: Math.max(0, Math.min(100, vitals.bond + 0.1)), // Bond increases slowly
    mood: Math.max(0, Math.min(100, vitals.mood - 0.3)), // Mood decreases
    hunger: Math.max(0, Math.min(100, vitals.hunger + 0.8)), // Hunger increases
    hygiene: Math.max(0, Math.min(100, vitals.hygiene - 0.4)), // Hygiene decreases
  };
}

// ===== UPGRADE 10: Procedural Behavior Engine =====
export type PetBehaviorState =
  | 'idle-happy'
  | 'idle-neutral'
  | 'idle-sad'
  | 'wander-energetic'
  | 'wander-tired'
  | 'panic-hungry'
  | 'panic-dirty'
  | 'sleep';

/**
 * Determines the pet's behavior state based on vitals
 */
export function getPetBehaviorState(vitals: Vitals): PetBehaviorState {
  // Emergency states
  if (vitals.energy < 15) return 'sleep';
  if (vitals.hunger > 80) return 'panic-hungry';
  if (vitals.hygiene < 20) return 'panic-dirty';

  // Mood-based states
  if (vitals.mood > 70) {
    return vitals.energy > 60 ? 'wander-energetic' : 'idle-happy';
  } else if (vitals.mood > 40) {
    return vitals.energy > 50 ? 'wander-energetic' : 'idle-neutral';
  } else {
    return vitals.energy > 40 ? 'wander-tired' : 'idle-sad';
  }
}

/**
 * Get animation parameters based on behavior state
 */
export function getAnimationParametersForState(state: PetBehaviorState): {
  scaleAmplitude: number;
  rotationSpeed: number;
  pulseFrequency: number;
} {
  const params: Record<PetBehaviorState, { scaleAmplitude: number; rotationSpeed: number; pulseFrequency: number }> = {
    'idle-happy': { scaleAmplitude: 0.3, rotationSpeed: 0.5, pulseFrequency: 1 },
    'idle-neutral': { scaleAmplitude: 0.2, rotationSpeed: 0.3, pulseFrequency: 0.8 },
    'idle-sad': { scaleAmplitude: 0.1, rotationSpeed: 0.1, pulseFrequency: 0.5 },
    'wander-energetic': { scaleAmplitude: 0.5, rotationSpeed: 2, pulseFrequency: 2 },
    'wander-tired': { scaleAmplitude: 0.15, rotationSpeed: 0.5, pulseFrequency: 0.6 },
    'panic-hungry': { scaleAmplitude: 0.6, rotationSpeed: 3, pulseFrequency: 3 },
    'panic-dirty': { scaleAmplitude: 0.4, rotationSpeed: 2.5, pulseFrequency: 2.5 },
    sleep: { scaleAmplitude: 0.05, rotationSpeed: 0, pulseFrequency: 0.2 },
  };

  return params[state];
}
